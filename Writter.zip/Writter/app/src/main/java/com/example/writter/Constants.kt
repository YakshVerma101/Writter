package com.example.writter

object Constants {
    val apiKey = "AIzaSyDrAtr-ecrpjZKFslIChQvLZ_a9wbqiDSU"
}